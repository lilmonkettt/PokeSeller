# PokéSeller

A local-first Pokémon card inventory and sales tracker. This is an unofficial fan-made project and is not affiliated with Pokémon or Nintendo.

## Run it
Open `index.html` in a modern browser, or use VS Code's Live Server extension. No build step is needed.

## Features
- Inventory, manual card entry, card search through TCGdex, optional card images
- Selling price and optional purchase cost per copy
- Cart, checkout, sales history, revenue and profit tracking
- Unknown purchase costs stay unknown and never count as zero profit
- CSV inventory export and JSON backup/restore
- Data saved in the current browser via localStorage

## Privacy and limitations
Data is stored locally in the browser; it is not cloud-synced. Download backups regularly. Card search sends the search term to the third-party TCGdex API and requires an internet connection. Editing a card's cost does not change past sales.

## Feedback
Once hosted on GitHub, enable Issues for bug reports. Include steps to reproduce, expected behaviour, actual behaviour, browser/device and a screenshot if useful. Never attach your private backup file to a public issue. Enable Discussions for general feedback if you want a review/ideas area.
